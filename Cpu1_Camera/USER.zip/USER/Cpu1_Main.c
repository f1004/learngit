

#include "headfile.h"
#include "isr.h"
#include "img.h"
#include <stdlib.h>
#include "pid.h"
#include "key.h"
#include "Ks103.h"
int16 encoder1;
int16 encoder2;
#define MOTOR1_A   ATOM0_CH0_P21_2   //����1�����תPWM����      ���1��������
#define MOTOR1_B   ATOM0_CH1_P21_3   //����1�����תPWM����

#define MOTOR2_A   ATOM0_CH2_P21_4   //����2�����תPWM����
#define MOTOR2_B   ATOM0_CH3_P21_5   //����2�����תPWM����
int32 speed1_power;
int32 speed2_power;
extern int front;
int set_speed;
int limit_increase;
int limit_out;
int left_pwm,right_pwm;
int speed_base;
int adc_error,adc_lasterror,adc_pwm;
char adc_p=5,adc_d=0;
uint32 distance,set_distance=200;
int  ad_value1;
int  ad_value2;
int  ad_value3;

uint32 tim;
int Threshold2;

#pragma section all "cpu1_dsram"

int core1_main(void)
{
	disableInterrupts();
	//get_clk();//��ȡʱ��Ƶ��  ��ر���
	//oled_init();
    gtm_pwm_init(MOTOR1_A, 17000, 0);
	gtm_pwm_init(MOTOR1_B, 17000, 0);
	gtm_pwm_init(MOTOR2_A, 17000, 0);
	gtm_pwm_init(MOTOR2_B, 17000, 0);
	//key_init();
	gpt12_init(GPT12_T2, GPT12_T2INB_P33_7, GPT12_T2EUDB_P33_6);
	gpt12_init(GPT12_T5, GPT12_T5INB_P10_3, GPT12_T5EUDB_P10_1);

	//uart_init(UART_0, 115200, UART0_TX_P14_0, UART0_RX_P14_1);

	enableInterrupts();
	lcd_init();	//��ʼ��IPS��Ļ
	lcd_showstr(0, 0, "SEEKFREE MT9V03x");
	lcd_showstr(0, 1, "Initializing...");
	//Ks103_init();
    //�û��ڴ˴����ø��ֳ�ʼ��������
	printf("printf demo");
	//icm20602_init_spi();
    enableInterrupts();
    lcd_init();
    mt9v03x_init();
    pit_interrupt_ms(CCU6_0, PIT_CH0, 5);
    int* histogram;
	speed_base=1500;
	set_speed=800;
	limit_increase=2000;
	limit_out=4000;
	left_pwm=500;
	right_pwm=400;
	systick_start(STM1);
//	adc_init(ADC_0, ADC0_CH0_A0);
//	adc_init(ADC_0, ADC0_CH1_A1);
//	adc_init(ADC_0, ADC0_CH2_A2);
    while (TRUE)
    {

//    	ad_value1=adc_get(ADC_0, ADC0_CH0_A0, ADC_8BIT);
//    	ad_value2=adc_get(ADC_0, ADC0_CH1_A1, ADC_8BIT);
//    	ad_value3=adc_get(ADC_0, ADC0_CH2_A2, ADC_8BIT);
    	adc_lasterror=adc_error;
    	adc_error=ad_value1-ad_value3;
    	adc_pwm=adc_p*adc_error+adc_d*(adc_error-adc_lasterror);








    	 if(key1_flag)
    	 {
    	 key1_flag=0;
    	 }

    	if (mt9v03x_finish_flag==1)
    	    	{

    	    	//printf(" %d\n", (int)Threshold2);

    			histogram = Histo(*mt9v03x_image);
    			Threshold2 = OtsuThreshold(histogram);
    			//Threshold2 = IterationThreshold(histogram);
    			free(histogram);
    			histogram=NULL;
    		   	Image_Binary(*mt9v03x_image, *BinaryImage,Threshold2);


//    	    	adapt_otsuThreshold(mt9v03x_image[0],MT9V03X_H ,  MT9V03X_W, &Threshold2);
//
//    	    	Image_Binary(mt9v03x_image, BinaryImage,Threshold2);

    			//lcd_displayimage032(*BinaryImage, MT9V03X_W, MT9V03X_H);
    		   	lcd_displayimage032(*BinaryImage, MT9V03X_W, MT9V03X_H);
    		    for (uint8 i=front+19;i>=front;i--)
    		   	          {
    		    	if (mid[i]>128) mid[i]=128;
    		   	    	 lcd_drawpoint((uint8)mid[i],i,RED);

    		   	          }
//    	        PID_Increase();
//    	        if(increase>=limit_increase)increase=limit_increase;
//    	        if(increase<=-limit_increase)increase=-limit_increase;
    		   	mt9v03x_finish_flag=0;




    	    	}


    if(Flag_10ms)
    {

    	//key_get();






//              speed1_power = speed_base+increase;
//              speed2_power = speed_base-increase;
//    	        speed1_power = increase;
//    	        speed2_power= -increase;
//        speed1_power = adc_pwm;
//        speed2_power= -adc_pwm;
//              speed1_power = out1+increase;
//              speed2_power = out2-increase;



//        data_conversion(encoder1 , encoder2, 4, 4,virtual_scope_data);

	   	tim=systick_getval_ms(STM1);
//	    distance=Ks103_getdistance();

	    lcd_showint32(20,7,ad_value1,7);
        lcd_showint32(80,7,ad_value2,7);
	    lcd_showint32(80,7,ad_value3,7);

//        lcd_showint32(20,7,speed1_power,7);
//        lcd_showint32(80,7,speed2_power,7);
//        lcd_showint32(80,7,total/20,7);
//        lcd_showint32(30,7,tim,5);
//        lcd_showint32(20,6,distance,7);
//        lcd_showint32(80,5,out2,7);
//        lcd_showint32(20,5,out1,7);
//        lcd_showint32(80,4,increase,7);
//	    lcd_showint32(20,7,distance,7);
//	    lcd_showint32(80,7,set_speed,7);




        if(distance<set_distance && tim>1000)
        {
        	set_speed=0;

        }

    	Flag_10ms=0;

    }












    	//ʹ��printf��ʱ�����ϣ�����η��͵������ܹ�������FSS������ʾ����Ӧ���������� \n ���򵥲����Ի����printf����֮��FSS����û����ʾ
    }
}




#pragma section all restore

