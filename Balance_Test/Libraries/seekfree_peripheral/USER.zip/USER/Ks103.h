/*
 * Ks103.h
 *
 *  Created on: 2020��7��18��
 *      Author: 1004
 */

#ifndef USER_KS103_H_
#define USER_KS103_H_
#include "common.h"

void Ks103_init(void);
int Ks103_getdistance(void);


#endif /* USER_KS103_H_ */
