/*********************************************************************************************************************
 * COPYRIGHT NOTICE
 * Copyright (c) 2020,��ɿƼ�
 * All rights reserved.
 * ��������QQȺ����Ⱥ��824575535
 *
 * �����������ݰ�Ȩ������ɿƼ����У�δ����������������ҵ��;��
 * ��ӭ��λʹ�ò������������޸�����ʱ���뱣����ɿƼ��İ�Ȩ������
 *
 * @file       		main
 * @company	   		�ɶ���ɿƼ����޹�˾
 * @author     		��ɿƼ�(QQ3184284598)
 * @version    		�鿴doc��version�ļ� �汾˵��
 * @Software 		tasking v6.3r1
 * @Target core		TC264D
 * @Taobao   		https://seekfree.taobao.com/
 * @date       		2020-3-23
 ********************************************************************************************************************/

#include "headfile.h"
#include "pid.h"
#pragma section all "cpu1_dsram"
int16 encoder1;
int16 encoder2;
int time1;
int32 speed1_power;
int32 speed2_power;
extern int front;
int set_speed=400;
int limit_increase;
int limit_out=2000;
int left_pwm=0,right_pwm=0;//400
int speed_base,adc_pwm;
int adc_error,adc_lasterror;
char adc_p1=5,adc_p2=5,adc_p3=50;
uint32 distance,set_distance=200;

char adc_p=15,adc_d=1;//20

void core1_main(void)
{
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());

    //�û��ڴ˴����ø��ֳ�ʼ��������
	lcd_init();
	adc_init(ADC_0, ADC0_CH0_A0);
	adc_init(ADC_0, ADC0_CH1_A1);
	adc_init(ADC_0, ADC0_CH2_A2);
	//uart_init(UART_1, 115200, UART1_TX_P11_12, UART1_RX_P11_10);
    //uart_putstr(UART_1, "\n---uart test---\n");
    //�û��ڴ˴����ø��ֳ�ʼ��������
	printf("printf demo");
	//icm20602_init_spi();
    pit_interrupt_ms(CCU6_0, PIT_CH0, 5);
	gtm_pwm_init(MOTOR1_A, 17000, 0);
	gtm_pwm_init(MOTOR1_B, 17000, 0);
	gtm_pwm_init(MOTOR2_A, 17000, 0);
	gtm_pwm_init(MOTOR2_B, 17000, 0);
	gpt12_init(GPT12_T2, GPT12_T2INB_P33_7, GPT12_T2EUDB_P33_6);
	gpt12_init(GPT12_T5, GPT12_T5INB_P10_3, GPT12_T5EUDB_P10_1);
    enableInterrupts();

    //oled_init();
    //mt9v03x_init();
   // int* histogram;

    while (TRUE)
    {    //systick_start(STM1);
      	adc_get(ADC_0, ADC0_CH0_A0,ADC0_CH1_A1,ADC0_CH2_A2, ADC_8BIT);


      //	time1=systick_getval_us(STM1);
//         ad_value1=adc_p1*last_value1+adc_p2*pre_value1+adc_p3*ad_value1/(adc_p1+adc_p2+adc_p3);
//         ad_value2=adc_p2*last_value2+adc_p2*pre_value2+adc_p3*ad_value2/(adc_p1+adc_p2+adc_p3);;
//         ad_value3=adc_p3*last_value3+adc_p3*pre_value3+adc_p3*ad_value3/(adc_p1+adc_p2+adc_p3);;



	    lcd_showint32(80,7,ad_value1,7);
        lcd_showint32(80,6,ad_value2,7);
	    lcd_showint32(80,5,ad_value3,7);
	    lcd_showint32(80,4,encoder1,7);
	    lcd_showint32(80,3,l_flag1,7);

	    lcd_showint32(80,2,adc_error,7);
	    lcd_showint32(80,1,speed1_power,7);
	    lcd_showint32(80,0,speed2_power,7);
	    lcd_showstr(20,7,"ad1");
	    lcd_showstr(20,6,"ad2");
	    lcd_showstr(20,5,"ad3");
	    lcd_showstr(20,4,"encoder1");
	    lcd_showstr(20,3,"l_flag1");
	    lcd_showstr(20,2,"error");
	    lcd_showstr(20,1,"sd1");
	    lcd_showstr(20,0,"sd2");


        //	        speed1_power = out1+increase;
        //	        speed2_power = out2-increase;

    	       last_value1= pre_value1;








    	

    }
}
#pragma section all restore
